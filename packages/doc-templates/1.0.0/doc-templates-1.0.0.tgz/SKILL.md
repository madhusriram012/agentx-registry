# doc-templates

Document format templates for restructuring messy text into professional documents. Each template defines STRUCTURE (sections, order), TYPOGRAPHY (font, sizes, spacing — apply when output supports styling), and RULES.

Default typography can be overridden by user input (e.g. "use Georgia 12pt").

---

## Template: professional (report / proposal / memo)

**Structure:**
1. Title (concise, no filler words)
2. Executive Summary — 3-5 sentences, readable standalone
3. Background / Context
4. Main sections with descriptive headings (not "Section 1")
5. Recommendations / Next Steps — actionable, numbered
6. Appendix (only if needed)

**Typography:** Font: Calibri or Helvetica Neue. Title 20pt bold. Headings 14pt bold. Body 11pt, line spacing 1.15. Margins 2.5cm. Numbered headings (1., 1.1) for docs > 3 pages.

**Rules:** No first person singular in reports ("we"/passive instead). Numbers and dates preserved exactly. One idea per paragraph, max 5 sentences. Bullet lists for 3+ parallel items.

**Example transformation:**
- Input: "so basically sales dropped in Q2 like 15% mainly cuz of the pricing change we did in april, tanaka thinks we should roll it back but idk"
- Output: "## Q2 Sales Performance\n\nSales declined 15% in Q2, primarily attributable to the April pricing change. Rolling back the change has been proposed (Tanaka) but requires further validation.\n\n### Recommendation\n1. Validate the pricing impact with cohort analysis before deciding on a rollback."

---

## Template: resume

**Structure:**
1. Name + contact line (email · phone · city · LinkedIn/GitHub)
2. Summary — 2-3 lines, tailored to target role, no objective statements
3. Experience — reverse chronological: **Role, Company** | dates; 3-5 bullets each
4. Skills — grouped (Languages / Tools / Domain)
5. Education — degree, institution, year
6. Optional: Certifications, Projects

**Typography:** Font: Garamond, Calibri, or Helvetica. Name 18pt bold. Section headings 12pt bold, small caps or underline. Body 10.5-11pt. Single page unless 10+ years experience. No photos, no tables, no columns (ATS-safe).

**Rules:** Every experience bullet starts with a strong past-tense verb (Led, Built, Reduced, Shipped). Quantify wherever possible ("reduced load time 40%", "team of 6"). No pronouns. No "responsible for". Cut anything not relevant to the target role.

**Example transformation:**
- Input: "i was working at ABC corp doing backend stuff, mostly python, fixed a lot of performance issues and also helped the juniors"
- Output: "**Backend Engineer, ABC Corp** | 2021–2024\n- Built and maintained Python backend services\n- Reduced API response times through targeted performance optimization\n- Mentored 3 junior engineers"

---

## Template: business-email

**Structure:**
1. Subject — specific, action-oriented, under 8 words
2. Greeting matched to relationship (Dear / Hi / Hello)
3. Purpose in the FIRST sentence
4. Context — 1-2 short paragraphs max
5. Clear ask or next step, with deadline if any
6. Sign-off (Best regards / Thanks) + name

**Typography:** Plain text priority. If rich text: Arial or Calibri 11pt, no colors, bold only for deadlines or the core ask.

**Rules:** Under 150 words unless unavoidable. One email = one ask. Deadline in its own sentence. No "I hope this email finds you well" openers. For Japanese business email: proper 宛名 → 挨拶 → 要件 → 結び structure with appropriate keigo level.

**Example transformation:**
- Input: "need the budget numbers from finance team before friday for the board thing"
- Output: "Subject: Budget figures needed by Friday for board meeting\n\nHi [Name],\n\nCould you share the Q3 budget figures by **Friday EOD**? They're needed for Monday's board meeting.\n\nHappy to jump on a call if anything is unclear.\n\nBest regards,\n[Name]"

---

## Template: meeting-minutes

**Structure:** Title (meeting + date) → Attendees → Summary (2-3 sentences) → Decisions → Action Items (table: Action | Owner | Due) → Open Questions.

**Typography:** Calibri 11pt, headings 13pt bold, table with header row bold.

**Rules:** Decisions only if actually decided. Never invent owners or dates — use "?". Terse; minutes are scanned, not read.

---

## Template: cover-letter

**Structure:** Contact header → Date → Hiring manager/company → 3 paragraphs: (1) role + strongest hook, (2) 2-3 specific achievements mapped to the job requirements, (3) enthusiasm + call to action → Sign-off.

**Typography:** Match resume font. Body 11pt. One page, 250-350 words.

**Rules:** Company name and role appear in paragraph 1. Every claim ties to a job requirement. No repetition of the resume — add narrative, not lists.

---

## Custom style input

Users may override any template's typography or supply a fully custom spec:
`font`, `size` (body pt), `heading_size`, `line_spacing`, `tone` (formal / neutral / friendly), `language`, `length` (target words/pages).

When output is HTML, apply typography as inline CSS. When output is markdown/plain text, state the typography spec at the top as a "Formatting note" the user can apply in Word/Google Docs.
