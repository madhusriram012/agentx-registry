# doc-formatter-agent

Turn messy documents into clean, formatted output. Pick a template — `professional`, `resume`, `business-email`, `meeting-minutes`, `cover-letter` — or give custom style input (font, size, tone, language). Preserves all facts; flags gaps as `[TODO]` instead of inventing content.

**See it before using it:** `examples/messy-input.txt` → `examples/formatted-output.md` (professional template).

## Get it

```bash
pip install agentx-cli
agentx get doc-formatter-agent
agentx install doc-formatter-agent   # pulls the doc-templates skill dependency
```

After install:

```
doc-formatter-agent/
  agent.yaml                  # the agent (system_prompt = its brain)
  examples/                   # before/after example
  agent_modules/
    doc-templates/SKILL.md    # template definitions (installed dependency)
  agent.lock
```

## Use it

**Claude / Claude Project:** paste `system_prompt` from `agent.yaml` as custom instructions, attach or paste `agent_modules/doc-templates/SKILL.md` once, then send your messy doc + template name ("format this as professional") or custom style ("Georgia 12pt, friendly tone, max 1 page").

**API:**
```python
import yaml, anthropic
a = yaml.safe_load(open("agent.yaml"))
templates = open("agent_modules/doc-templates/SKILL.md").read()
client = anthropic.Anthropic()
msg = client.messages.create(
    model=a["model"], max_tokens=4000,
    system=a["system_prompt"] + "\n\n<doc-templates skill>\n" + templates + "\n</doc-templates skill>",
    messages=[{"role": "user", "content": f"Format as professional:\n\n{MESSY_DOC}"}],
)
print(msg.content[0].text)
```

**Try it immediately** with the bundled example: send `examples/messy-input.txt` and compare against `examples/formatted-output.md`.

## Extend it

- Add your own templates: fork `doc-templates`, add a template section to SKILL.md, publish as a new version — this agent picks it up via `doc-templates@^1.0.0`.
- Change behavior: edit `system_prompt`, bump `version` in `agent.yaml`, publish your variant.
